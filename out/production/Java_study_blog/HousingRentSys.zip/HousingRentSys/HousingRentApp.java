package HousingRentSys;

public class HousingRentApp {
    public static void main(String[] args) {
        new HousingRentCode().mainMenu();
    }
}
