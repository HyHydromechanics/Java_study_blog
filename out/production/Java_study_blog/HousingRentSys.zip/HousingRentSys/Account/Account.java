package HousingRentSys.Account;

import HousingRentSys.HousingRentCode;
import HousingRentSys.utils.Utility;

import java.util.Objects;



public class Account {
    String userNameNew;
    String  passWordNew;
    String command;
    boolean accountVer = false;
    boolean root = false;
    boolean loop = true;
    HousingRentCode housingRentCode = new HousingRentCode();
    Utility utility = new Utility();

    public void AccountA(){
        do {
            System.out.println("======Account======");
            System.out.println("\t\t\t1 Register");
            System.out.println("\t\t\t2 Log in");
            System.out.println("\t\t\t3 Quit");
            command = scanner.next();
            switch (command){
                case "1":
                    this.Reg();
                case "2":
                    this.LoginVer();
                case "3":
                    housingRentCode.mainMenu();
                default:
                    System.out.println("Please press 1~3");

            }
        } while (loop);
    }
    public void Reg(){
        int chance = 3;
        System.out.println("You've encountered in the register system");
        System.out.println("Now, you shall create a account:");
        System.out.println("Write your username");
        userNameNew = scanner.next();

        System.out.println("Write your password:");
        passWordNew = scanner.next();
        System.out.println("Write your password again to confirm");
        String passWord2 = scanner.next();
        if (passWordNew.equals(passWord2)){
            this.LoginVer();
        }
        else {
            System.out.println("Password Wrong");
        }
    }
    private void LoginVer(){
        String userName = "root";
        String passWord = "root";
        int chance = 3;
        System.out.println("You've encountered the Login System");
        System.out.println("Now, you shall login to your account if you have one(press 1 to continue, press 2 to register a account)");

        command = scanner.next();
        switch (command){
            case "1":
                this.Login();
            case "2":
                this.Reg();
            case "3":
                System.out.println("login as the root user");
                System.out.println("Username?");
                String userNameRootLog = scanner.next();
                System.out.println("Password?");
                String userPasswordRootLog = scanner.next();
                if (Objects.equals(userNameRootLog, userName)&&Objects.equals(userPasswordRootLog,passWord)){
                    System.out.println("You have logged in as the root user successfully");
                    root = true;
                } else {
                    break;
                }

        }

    }

    public void Login() {
        System.out.println("UserName? ");
        String userName = scanner.next();
        System.out.println("Password? ");
        String  password = scanner.next();
        if (userName.equals(userNameNew)&&password.equals(passWordNew)){
            System.out.println("You've successfully logged in");
            accountVer = true;
        }
    }
}

