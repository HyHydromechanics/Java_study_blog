package HousingRentSys;

import HousingRentSys.Account.Account;

import java.util.Objects;
import java.util.Scanner;

public class HousingRentCode {
    Scanner scanner = new Scanner(System.in);
    boolean loop = true;
    String command;

    Account account = new Account();

    public void mainMenu(){
        do {
            System.out.println("\n================Menu===============");
            System.out.println("\t\t\t1 Account Management");
            System.out.println("\t\t\t2 Manage House");
            System.out.println("\t\t\t3 Find User or House");
            System.out.println("\t\t\t4 House List");
            System.out.println("\t\t\t5 Quit");

            System.out.println("Please choose 1~5");
            command = scanner.next();
            switch (command){
                case "1":
                    account.AccountA();
                case "2":
                    this.HouseMenu();
                case "3":
                    this.Find();
                case "4":
                    this.HouseList();
                case "5":
                    this.Quit();
                default:
                    System.out.println("Please Press 1~5");
            }
        } while (loop);

    }



    public void HouseMenu(){
        loop = true;
        do{
            System.out.println("------House Menu------");
            System.out.println("\t\t\t1 Add a house");
            System.out.println("\t\t\t2 Delete a house");
            System.out.println("\t\t\t3 Change a house");
            System.out.println("\t\t\t4 Quit");
            command = scanner.next();
            switch (command){
                case "1":
                    this.AddHouse();
                case "2":
                    this.DeleteHouse();
                case "3":
                    this.ChangeHouse();
                case "4":
                    this.mainMenu();
                default:
                    System.out.println("Please press 1~3");
            }
        } while (loop);

    }

    public void AddHouse(){

    }
    public void DeleteHouse(){
    }
    public void ChangeHouse(){
    }

    public void Find(){

    }
    public void HouseList(){

    }
    public void Quit(){
        System.out.println("-----Quit-----");
        System.out.println("Are you sure you want to quit this program?\n(Y/n)");
        String yes = "y";
        String Yes = "Y";
        String no = "n";
        String quitCommand = scanner.next();
        if (quitCommand.equals(yes) || quitCommand.equals(Yes)){
            loop = false;
            System.out.println("Goodbye");
        } else if (quitCommand.equals(no)){
            loop = true;
        } else System.out.println("Please type Y/n to conform");
    }
}


